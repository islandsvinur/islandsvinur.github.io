
#include <stdio.h>

int main(void) {
  int val;
  int x, y;

  x = 7; y = 10;

  
  printf("%i", x % y);

  return 0;
}

